import 'package:flutter/material.dart';

void main() => runApp(const TaskManagerApp());

class TaskManagerApp extends StatelessWidget {
  const TaskManagerApp({super.key});
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      theme: ThemeData(brightness: Brightness.dark, scaffoldBackgroundColor: const Color(0xFF1B1D22)),
      home: const TaskManagerScreen(),
    );
  }
}

class Task {
  String title;
  bool done;
  Task(this.title, this.done);
}

class TaskManagerScreen extends StatefulWidget {
  const TaskManagerScreen({super.key});
  @override
  State<TaskManagerScreen> createState() => _TaskManagerScreenState();
}

class _TaskManagerScreenState extends State<TaskManagerScreen> {
  final _controller = TextEditingController();
  final List<Task> _tasks = [];
  double _priority = 2;

  void _addTask() {
    if (_controller.text.trim().isEmpty) {
      ScaffoldMessenger.of(context)
          .showSnackBar(const SnackBar(content: Text('Enter a task title first')));
      return;
    }
    setState(() {
      _tasks.add(Task(_controller.text.trim(), false));
      _controller.clear();
    });
    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Task added')));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Zynxis Task Manager')),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            TextField(
              controller: _controller,
              style: const TextStyle(color: Colors.white),
              decoration: const InputDecoration(
                labelText: 'New task',
                labelStyle: TextStyle(color: Colors.white70),
                enabledBorder: OutlineInputBorder(borderSide: BorderSide(color: Colors.white24)),
              ),
            ),
            const SizedBox(height: 12),
            Row(
              children: [
                const Text('Priority', style: TextStyle(color: Colors.white70)),
                Expanded(
                  child: Slider(
                    value: _priority,
                    min: 1,
                    max: 5,
                    divisions: 4,
                    label: _priority.round().toString(),
                    onChanged: (v) => setState(() => _priority = v),
                  ),
                ),
              ],
            ),
            ElevatedButton(onPressed: _addTask, child: const Text('Add Task')),
            const SizedBox(height: 12),
            Expanded(
              child: ListView.builder(
                itemCount: _tasks.length,
                itemBuilder: (context, i) {
                  final t = _tasks[i];
                  return CheckboxListTile(
                    title: Text(t.title,
                        style: TextStyle(
                          color: Colors.white,
                          decoration: t.done ? TextDecoration.lineThrough : null,
                        )),
                    value: t.done,
                    onChanged: (v) => setState(() => t.done = v ?? false),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}