import 'package:flutter/material.dart';

void main() => runApp(const ZynxisLayoutApp());

const bgColor = Color(0xFF1B1D22);
const cardColor = Color(0xFF2A2D35);
const accent = Color(0xFF4A90E2);

class ZynxisLayoutApp extends StatelessWidget {
  const ZynxisLayoutApp({super.key});
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      theme: ThemeData(brightness: Brightness.dark, scaffoldBackgroundColor: bgColor),
      home: const LandingShell(),
    );
  }
}

class LandingShell extends StatefulWidget {
  const LandingShell({super.key});
  @override
  State<LandingShell> createState() => _LandingShellState();
}

class _LandingShellState extends State<LandingShell> {
  int _index = 0;
  final _pages = const [HomeTab(), AboutTab(), ServicesTab()];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(backgroundColor: cardColor, title: const Text('Zynxis')),
      body: _pages[_index],
      bottomNavigationBar: BottomNavigationBar(
        backgroundColor: cardColor,
        selectedItemColor: accent,
        unselectedItemColor: Colors.white54,
        currentIndex: _index,
        onTap: (i) => setState(() => _index = i),
        items: const [
          BottomNavigationBarItem(icon: Icon(Icons.home), label: 'Home'),
          BottomNavigationBarItem(icon: Icon(Icons.info), label: 'About'),
          BottomNavigationBarItem(icon: Icon(Icons.build), label: 'Services'),
        ],
      ),
    );
  }
}

class HomeTab extends StatelessWidget {
  const HomeTab({super.key});
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(24),
            decoration: BoxDecoration(color: cardColor, borderRadius: BorderRadius.circular(16)),
            child: const Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('Build. Learn. Ship.',
                    style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold, color: Colors.white)),
                SizedBox(height: 8),
                Text('Zynxis internships turn students into real developers.',
                    style: TextStyle(color: Colors.white70)),
              ],
            ),
          ),
          const SizedBox(height: 20),
          Row(
            children: [
              Expanded(child: _StatBox(label: 'Interns', value: '120+')),
              const SizedBox(width: 12),
              Expanded(child: _StatBox(label: 'Projects', value: '40+')),
            ],
          ),
        ],
      ),
    );
  }
}

class _StatBox extends StatelessWidget {
  final String label, value;
  const _StatBox({required this.label, required this.value});
  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(color: cardColor, borderRadius: BorderRadius.circular(12)),
      child: Column(
        children: [
          Text(value, style: const TextStyle(fontSize: 22, color: accent, fontWeight: FontWeight.bold)),
          Text(label, style: const TextStyle(color: Colors.white70)),
        ],
      ),
    );
  }
}

class AboutTab extends StatelessWidget {
  const AboutTab({super.key});
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(20),
      child: Stack(
        children: [
          Container(
            height: 160,
            decoration: BoxDecoration(color: cardColor, borderRadius: BorderRadius.circular(16)),
          ),
          Positioned(
            left: 16,
            top: 16,
            right: 16,
            child: const Text(
              'Zynxis was founded to bridge the gap between classroom '
                  'learning and industry-ready mobile development skills.',
              style: TextStyle(color: Colors.white, fontSize: 15),
            ),
          ),
        ],
      ),
    );
  }
}

class ServicesTab extends StatelessWidget {
  const ServicesTab({super.key});
  final services = const ['App Development', 'UI/UX Design', 'Backend & APIs', 'Cloud Deployment'];
  @override
  Widget build(BuildContext context) {
    return ListView.builder(
      padding: const EdgeInsets.all(20),
      itemCount: services.length,
      itemBuilder: (context, i) => Container(
        margin: const EdgeInsets.only(bottom: 12),
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(color: cardColor, borderRadius: BorderRadius.circular(12)),
        child: Row(
          children: [
            const Icon(Icons.check_circle, color: accent),
            const SizedBox(width: 12),
            Text(services[i], style: const TextStyle(color: Colors.white, fontSize: 16)),
          ],
        ),
      ),
    );
  }
}